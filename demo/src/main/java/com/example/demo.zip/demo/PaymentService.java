package com.example.demo;

public interface PaymentService {
    void processPayment(double amount);
}
